interface AssocStringString {
    [key: string]: string;
}

interface GamerData {
    name: string;
    scoreOfGame: number;
}